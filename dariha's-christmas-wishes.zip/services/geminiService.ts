import { GoogleGenAI } from "@google/genai";
import { GEMINI_MODEL, PROMPT_TEMPLATE } from "../constants";

let aiClient: GoogleGenAI | null = null;

const getAiClient = (): GoogleGenAI => {
  if (!aiClient) {
    aiClient = new GoogleGenAI({ apiKey: process.env.API_KEY });
  }
  return aiClient;
};

export const generateLuxuryGreeting = async (name: string): Promise<string> => {
  try {
    const ai = getAiClient();
    const prompt = `User Name: ${name}. ${PROMPT_TEMPLATE}`;
    
    const response = await ai.models.generateContent({
      model: GEMINI_MODEL,
      contents: prompt,
    });

    return response.text?.trim() || "Wishing you a season of brilliance and elegance.";
  } catch (error) {
    console.error("Gemini API Error:", error);
    return "May your holidays be as timeless as gold.";
  }
};
