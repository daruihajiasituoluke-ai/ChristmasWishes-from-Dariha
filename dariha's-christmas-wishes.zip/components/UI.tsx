import React, { useState } from 'react';
import { generateLuxuryGreeting } from '../services/geminiService';
import { AppState, GreetingResponse } from '../types';
import { Sparkles as SparkleIcon, X, Box, Triangle, Gem } from 'lucide-react';
import { COLORS } from '../constants';

interface UIProps {
  isAssembled: boolean;
  setIsAssembled: (val: boolean) => void;
}

export const UI: React.FC<UIProps> = ({ isAssembled, setIsAssembled }) => {
  const [state, setState] = useState<AppState>(AppState.IDLE);
  const [userName, setUserName] = useState('');
  const [wish, setWish] = useState('');

  const handleGenerate = async () => {
    if (!userName.trim()) return;
    if (!isAssembled) setIsAssembled(true);

    setState(AppState.GENERATING);
    const result = await generateLuxuryGreeting(userName);
    setWish(result);
    setState(AppState.SHOWING_WISH);
  };

  const handleReset = () => {
    setUserName('');
    setWish('');
    setState(AppState.IDLE);
  };

  const toggleAssemble = () => {
    setIsAssembled(!isAssembled);
  };

  return (
    <div className="absolute inset-0 pointer-events-none flex flex-col items-center justify-end pb-8 z-10 font-sans">
      
      {/* Controls Container - Royal Blue Glass */}
      <div className="pointer-events-auto flex flex-col items-center w-full max-w-sm gap-3 scale-90 origin-bottom transition-all duration-500">
        
        {/* Morph Toggle - Gold/Blue Pill */}
        <button 
          onClick={toggleAssemble}
          className="group flex items-center gap-2 bg-[#0F52BA]/60 backdrop-blur-md border border-[#FFD700]/40 px-5 py-2 rounded-full text-[#FFD700] text-[10px] uppercase tracking-[0.2em] hover:bg-[#0F52BA]/80 hover:border-[#FFD700] transition-all mb-2 shadow-[0_0_20px_rgba(255,215,0,0.2)]"
        >
          {isAssembled ? <Box size={12} className="text-[#FFD700]" /> : <Triangle size={12} className="rotate-180 text-[#FFD700]" />}
          <span>{isAssembled ? "Deconstruct" : "Assemble"}</span>
        </button>

        {state === AppState.IDLE && (
          <div className="w-full bg-[#02040a]/80 backdrop-blur-xl border border-[#0F52BA]/40 p-5 rounded-2xl shadow-2xl relative overflow-hidden">
            {/* Decorative Gold Line */}
            <div className="absolute top-0 left-0 w-full h-[2px] bg-gradient-to-r from-transparent via-[#FFD700] to-transparent opacity-50"></div>
            
            <label className="block text-[#F5F5F5] text-[11px] uppercase tracking-widest mb-3 text-center font-serif">
              Arix Signature Concierge
            </label>
            <div className="flex gap-2">
              <input
                type="text"
                value={userName}
                onChange={(e) => setUserName(e.target.value)}
                placeholder="Your Name"
                className="flex-1 bg-white/5 border border-[#FFD700]/20 text-[#FFD700] px-3 py-2.5 rounded-lg text-sm outline-none focus:border-[#FFD700] font-serif placeholder:text-[#FFD700]/30 text-center transition-colors"
              />
              <button
                onClick={handleGenerate}
                disabled={!userName.trim()}
                className="bg-[#FFD700] text-[#02040a] font-bold py-2 px-5 rounded-lg text-xs uppercase tracking-wider hover:bg-[#F5BD02] active:scale-95 transition-all disabled:opacity-40 disabled:cursor-not-allowed shadow-[0_0_15px_rgba(255,215,0,0.3)]"
              >
                Reveal
              </button>
            </div>
          </div>
        )}

        {state === AppState.GENERATING && (
          <div className="text-center bg-[#0F52BA]/40 backdrop-blur-md p-6 rounded-2xl border border-[#FFD700]/20">
            <div className="inline-block w-8 h-8 border-2 border-[#FFD700] border-t-transparent rounded-full animate-spin mb-3" />
            <p className="text-[#FFD700] tracking-[0.3em] text-[10px] animate-pulse">
              CURATING...
            </p>
          </div>
        )}

        {state === AppState.SHOWING_WISH && (
          <div className="relative w-full bg-[#02040a]/90 backdrop-blur-xl border border-[#FFD700]/30 p-8 rounded-2xl text-center transform transition-all duration-700 animate-in fade-in slide-in-from-bottom-10 shadow-[0_0_40px_rgba(15,82,186,0.3)]">
             <button 
              onClick={handleReset}
              className="absolute top-3 right-3 text-[#FFD700]/40 hover:text-[#FFD700] transition-colors"
            >
              <X size={16} />
            </button>
            
            <Gem className="inline-block text-[#FFD700] mb-4 drop-shadow-[0_0_10px_rgba(255,215,0,0.5)]" size={20} />
            
            <h2 className="text-xl md:text-2xl font-serif text-[#F5F5F5] italic mb-4 leading-relaxed">
              "{wish}"
            </h2>
            
            <div className="w-12 h-[1px] bg-[#FFD700] mx-auto mb-3 opacity-50"></div>
            
            <p className="text-[#0F52BA] text-[10px] uppercase tracking-[0.2em] font-bold">
              For {userName}
            </p>
          </div>
        )}
      </div>

      <footer className="text-[#FFD700]/30 text-[9px] tracking-[0.2em] mt-4 font-serif">
        &copy; {new Date().getFullYear()} ARIX SIGNATURE
      </footer>
    </div>
  );
};