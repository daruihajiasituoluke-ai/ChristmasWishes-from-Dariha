import React, { useMemo, useRef, useLayoutEffect } from 'react';
import { useFrame } from '@react-three/fiber';
import { Sparkles } from '@react-three/drei';
import * as THREE from 'three';
import { COLORS } from '../constants';

interface OrnamentsProps {
  isAssembled: boolean;
}

// --- CONFIG ---
const SPHERE_COUNT = 250; // Very high density
const SPRAY_COUNT = 150; // Gold twigs/wheat
const GIFT_COUNT = 40;

// Colors
const COLOR_GOLD = new THREE.Color(COLORS.GOLD_METALLIC);
const COLOR_BLUE = new THREE.Color(COLORS.EMERALD_MAIN);
const COLOR_WHITE = new THREE.Color(COLORS.EMERALD_LIGHT);

// --- HELPER: Random Festive Color Logic ---
const getOrnamentColor = () => {
    const r = Math.random();
    if (r < 0.55) return COLOR_GOLD; // 55% Gold
    if (r < 0.85) return COLOR_BLUE; // 30% Blue
    return COLOR_WHITE; // 15% White
};

type OrnamentData = {
  scatterPos: THREE.Vector3;
  treePos: THREE.Vector3;
  scale: number;
  rotationSpeed: THREE.Vector3;
  phase: number;
  color: THREE.Color;
  roughness: number;
};

// --- HELPER: Positioning ---
const getConePos = (height: number, maxRadius: number, yOffset: number) => {
    const h = Math.random() * height;
    const rAtH = maxRadius * (1 - h / height);
    const angle = Math.random() * Math.PI * 2;
    // Push mostly to surface
    const r = rAtH * (0.8 + 0.2 * Math.random()); 
    const x = Math.cos(angle) * r;
    const z = Math.sin(angle) * r;
    const y = h + yOffset;
    return { pos: new THREE.Vector3(x, y, z), normal: new THREE.Vector3(x, 0, z).normalize() };
};

const randomSpherePos = (radius: number) => {
  const u = Math.random();
  const v = Math.random();
  const theta = 2 * Math.PI * u;
  const phi = Math.acos(2 * v - 1);
  const r = Math.cbrt(Math.random()) * radius;
  return new THREE.Vector3(
    r * Math.sin(phi) * Math.cos(theta),
    r * Math.sin(phi) * Math.sin(theta),
    r * Math.cos(phi)
  );
};

export const InstancedOrnaments: React.FC<OrnamentsProps> = ({ isAssembled }) => {
  const sphereMesh = useRef<THREE.InstancedMesh>(null);
  const sprayMesh = useRef<THREE.InstancedMesh>(null);
  const giftMesh = useRef<THREE.InstancedMesh>(null);

  // --- DATA GENERATION ---
  const { spheres, sprays, gifts } = useMemo(() => {
    
    // 1. SPHERES (Baubles)
    const sData: OrnamentData[] = [];
    for(let i=0; i<SPHERE_COUNT; i++) {
        const { pos } = getConePos(6.5, 2.6, -3.2);
        // Push out slightly to sit ON the foliage
        pos.add(pos.clone().normalize().multiplyScalar(0.2));
        
        const color = getOrnamentColor();
        // Shiny gold/blue, Matte white/some gold
        const isMatte = (color === COLOR_GOLD && Math.random() > 0.7) || (color === COLOR_WHITE);

        sData.push({
            scatterPos: randomSpherePos(10),
            treePos: pos,
            scale: Math.random() * 0.15 + 0.1, // Mixed sizes
            rotationSpeed: new THREE.Vector3(Math.random(), Math.random(), Math.random()),
            phase: Math.random() * Math.PI * 2,
            color: color,
            roughness: isMatte ? 0.6 : 0.1
        });
    }

    // 2. SPRAYS (Gold Wheat/Branches) - Thin cylinders sticking out
    const spData: OrnamentData[] = [];
    for(let i=0; i<SPRAY_COUNT; i++) {
        const { pos, normal } = getConePos(6.0, 2.4, -3.0);
        // Stick out further
        const treePos = pos.clone().add(normal.multiplyScalar(0.3));
        
        // Orient rotation to point outwards? 
        // For InstancedMesh, we'll handle rotation in useFrame or bake it.
        // Actually, better to store the lookAt target (normal) in rotationSpeed for now.
        
        spData.push({
            scatterPos: randomSpherePos(10),
            treePos: treePos,
            scale: Math.random() * 0.5 + 0.5, // Length variation
            rotationSpeed: normal, // HACK: Storing normal vector here
            phase: Math.random() * Math.PI * 2,
            color: COLOR_GOLD,
            roughness: 0.2
        });
    }

    // 3. GIFTS - Bottom of tree
    const gData: OrnamentData[] = [];
    for(let i=0; i<GIFT_COUNT; i++) {
        const angle = Math.random() * Math.PI * 2;
        const r = 2.0 + Math.random() * 2.0; // Spread around base
        const x = Math.cos(angle) * r;
        const z = Math.sin(angle) * r;
        
        gData.push({
            scatterPos: randomSpherePos(8),
            treePos: new THREE.Vector3(x, -3.2, z),
            scale: 0.4 + Math.random() * 0.4,
            rotationSpeed: new THREE.Vector3(0, Math.random(), 0),
            phase: Math.random() * Math.PI * 2,
            color: Math.random() > 0.5 ? COLOR_WHITE : COLOR_BLUE,
            roughness: 0.5
        });
    }

    return { spheres: sData, sprays: spData, gifts: gData };
  }, []);

  // --- INITIALIZE COLORS ---
  useLayoutEffect(() => {
    const apply = (mesh: THREE.InstancedMesh | null, data: OrnamentData[]) => {
        if (!mesh) return;
        data.forEach((d, i) => {
           if(mesh.instanceColor) mesh.setColorAt(i, d.color);
        });
        if(mesh.instanceColor) mesh.instanceColor.needsUpdate = true;
    };
    apply(sphereMesh.current, spheres);
    apply(sprayMesh.current, sprays);
    apply(giftMesh.current, gifts);
  }, [spheres, sprays, gifts]);

  // --- ANIMATION LOOP ---
  useFrame((state, delta) => {
    const time = state.clock.elapsedTime;
    const dummy = new THREE.Object3D();
    const target = isAssembled ? 1 : 0;
    
    // Lerp factor
    const lerp = THREE.MathUtils.damp(sphereMesh.current?.userData.lerp || 0, target, 2, delta);
    if (sphereMesh.current) sphereMesh.current.userData.lerp = lerp;

    // 1. SPHERES
    if (sphereMesh.current) {
        spheres.forEach((d, i) => {
            dummy.position.lerpVectors(d.scatterPos, d.treePos, lerp);
            dummy.scale.setScalar(d.scale * lerp);
            dummy.rotation.set(time * 0.2, time * 0.2, 0);
            dummy.updateMatrix();
            sphereMesh.current!.setMatrixAt(i, dummy.matrix);
        });
        sphereMesh.current.instanceMatrix.needsUpdate = true;
    }

    // 2. SPRAYS (Point outwards)
    if (sprayMesh.current) {
        sprays.forEach((d, i) => {
            dummy.position.lerpVectors(d.scatterPos, d.treePos, lerp);
            // Look at logic: From tree center (0, y, 0) to position
            const lookTarget = dummy.position.clone().add(d.rotationSpeed); // normal stored in rotationSpeed
            dummy.lookAt(lookTarget);
            dummy.scale.set(0.02, 0.02, d.scale * lerp); // Thin long cylinders
            dummy.updateMatrix();
            sprayMesh.current!.setMatrixAt(i, dummy.matrix);
        });
        sprayMesh.current.instanceMatrix.needsUpdate = true;
    }

    // 3. GIFTS
    if (giftMesh.current) {
        gifts.forEach((d, i) => {
            dummy.position.lerpVectors(d.scatterPos, d.treePos, lerp);
            dummy.scale.setScalar(d.scale * lerp);
            dummy.rotation.y = d.rotationSpeed.y * time;
            dummy.updateMatrix();
            giftMesh.current!.setMatrixAt(i, dummy.matrix);
        });
        giftMesh.current.instanceMatrix.needsUpdate = true;
    }
  });

  return (
    <group>
      {/* SPHERES */}
      <instancedMesh ref={sphereMesh} args={[undefined, undefined, SPHERE_COUNT]} castShadow receiveShadow>
        <sphereGeometry args={[1, 16, 16]} />
        <meshStandardMaterial metalness={0.9} roughness={0.2} envMapIntensity={1.5} />
      </instancedMesh>

      {/* SPRAYS (Gold Wheat) - Thin Cylinders */}
      <instancedMesh ref={sprayMesh} args={[undefined, undefined, SPRAY_COUNT]} castShadow>
        <cylinderGeometry args={[1, 0.1, 1, 6]} /> 
        {/* Radius 1 is scaled down by dummy.scale.x/y */}
        <meshStandardMaterial color={COLORS.GOLD_METALLIC} metalness={1} roughness={0.2} />
      </instancedMesh>

      {/* GIFTS */}
      <instancedMesh ref={giftMesh} args={[undefined, undefined, GIFT_COUNT]} castShadow>
        <boxGeometry args={[1, 1, 1]} />
        <meshStandardMaterial roughness={0.5} />
      </instancedMesh>
    </group>
  );
};

// --- RIBBON SYSTEM ---
const RibbonCurve: React.FC<{ 
  color: string, 
  radiusOffset: number, 
  width: number, 
  turns: number, 
  yStart: number, 
  yEnd: number,
  isAssembled: boolean 
}> = ({ color, radiusOffset, width, turns, yStart, yEnd, isAssembled }) => {
    
    const ref = useRef<THREE.Mesh>(null);
    const materialRef = useRef<THREE.MeshStandardMaterial>(null);

    const path = useMemo(() => {
        const points = [];
        const steps = 100;
        for (let i = 0; i <= steps; i++) {
            const t = i / steps;
            const y = THREE.MathUtils.lerp(yStart, yEnd, t);
            
            // Cone Radius at height y
            const hNorm = (y - yStart) / (yEnd - yStart); // 0 at bottom, 1 at top
            // Inverse logic: yStart is bottom (-3), yEnd is top (3)
            // Wait, tree is -3.5 to 3.5. 
            // Radius at base ~2.8, Radius at top ~0.
            const coneR = 2.9 * (1 - (y + 3.5) / 7);
            
            const theta = t * Math.PI * 2 * turns;
            
            // Add S-Wave perturbation
            const r = coneR + radiusOffset + Math.sin(t * 30) * 0.1; 
            
            const x = Math.cos(theta) * r;
            const z = Math.sin(theta) * r;
            points.push(new THREE.Vector3(x, y, z));
        }
        return new THREE.CatmullRomCurve3(points);
    }, [radiusOffset, turns, yStart, yEnd]);

    useFrame((state, delta) => {
        const target = isAssembled ? 1 : 0;
        // Simple fade/grow effect
        if(ref.current) {
            ref.current.scale.setScalar(THREE.MathUtils.lerp(ref.current.scale.x, target, delta * 3));
        }
        if(materialRef.current) {
             materialRef.current.opacity = THREE.MathUtils.lerp(materialRef.current.opacity, target, delta * 3);
        }
    });

    return (
        <mesh ref={ref} scale={[0,0,0]}>
            <tubeGeometry args={[path, 100, width, 8, false]} />
            <meshStandardMaterial 
                ref={materialRef}
                color={color} 
                metalness={0.6} 
                roughness={0.4} 
                side={THREE.DoubleSide} 
                transparent 
            />
        </mesh>
    );
};

// --- TOPPER: Golden Spray / Sunburst ---
export const Topper: React.FC<{ isAssembled: boolean }> = ({ isAssembled }) => {
    const groupRef = useRef<THREE.Group>(null);

    useFrame((state, delta) => {
        const target = isAssembled ? 1 : 0;
        if(groupRef.current) {
             const s = THREE.MathUtils.damp(groupRef.current.scale.x, target, 2, delta);
             groupRef.current.scale.setScalar(s);
             groupRef.current.rotation.y += delta * 0.2;
             
             // Move from sky
             const y = THREE.MathUtils.lerp(10, 3.5, s);
             groupRef.current.position.set(0, y, 0);
        }
    });

    const spikes = useMemo(() => {
        return new Array(40).fill(0).map((_, i) => {
            const phi = Math.acos( -1 + ( 2 * i ) / 40 );
            const theta = Math.sqrt( 40 * Math.PI ) * phi;
            return {
                rot: [Math.random() * Math.PI, Math.random() * Math.PI, Math.random() * Math.PI],
                dir: new THREE.Vector3(
                    Math.cos(theta) * Math.sin(phi),
                    Math.sin(theta) * Math.sin(phi),
                    Math.cos(phi)
                ),
                scale: Math.random() * 0.8 + 0.4
            };
        });
    }, []);

    return (
        <group ref={groupRef}>
             {spikes.map((s, i) => (
                 <mesh key={i} position={[0,0,0]} quaternion={new THREE.Quaternion().setFromUnitVectors(new THREE.Vector3(0,1,0), s.dir)}>
                     <cylinderGeometry args={[0.02, 0.05, s.scale * 1.5, 8]} />
                     <meshStandardMaterial 
                        color={COLORS.GOLD_METALLIC} 
                        emissive={COLORS.GOLD_METALLIC} 
                        emissiveIntensity={2} 
                        toneMapped={false} 
                     />
                 </mesh>
             ))}
             <Sparkles count={30} scale={2} size={4} color={COLORS.GOLD_METALLIC} />
        </group>
    );
};

export const OrnamentsContainer: React.FC<OrnamentsProps> = (props) => {
    return (
        <group>
            <InstancedOrnaments {...props} />
            
            {/* Blue Ribbon - Wide */}
            <RibbonCurve 
                color={COLORS.EMERALD_MAIN} 
                radiusOffset={0.2} 
                width={0.15} 
                turns={4} 
                yStart={-3} 
                yEnd={3} 
                isAssembled={props.isAssembled} 
            />
             {/* Gold Ribbon - Thin, intertwined */}
             <RibbonCurve 
                color={COLORS.GOLD_METALLIC} 
                radiusOffset={0.25} 
                width={0.06} 
                turns={4.5} 
                yStart={-2.8} 
                yEnd={3.2} 
                isAssembled={props.isAssembled} 
            />
            
            <Topper {...props} />
        </group>
    );
};