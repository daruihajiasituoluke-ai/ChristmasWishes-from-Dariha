import React, { useMemo, useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import * as THREE from 'three';
import { COLORS } from '../constants';

interface FoliageProps {
  isAssembled: boolean;
}

const vertexShader = `
  uniform float uTime;
  uniform float uProgress; // 0 = scattered, 1 = assembled
  
  attribute vec3 aTreePos;
  attribute float aSize;
  attribute float aRandom;
  
  varying vec3 vColor;
  varying float vAlpha;

  // Cubic Ease In/Out for smoother GPU transition
  float easeInOutCubic(float x) {
    return x < 0.5 ? 4.0 * x * x * x : 1.0 - pow(-2.0 * x + 2.0, 3.0) / 2.0;
  }

  void main() {
    vColor = color;
    
    // Smooth progress
    float t = easeInOutCubic(uProgress);
    
    // Interpolate position
    vec3 finalPos = mix(position, aTreePos, t);
    
    // Add "Breathing" and "Drift" logic
    float driftIntensity = (1.0 - t) * 0.8;
    float swayIntensity = t * 0.05; // Minimal sway for dense tree
    
    float time = uTime * 0.5;
    vec3 offset = vec3(
      sin(time + aRandom * 10.0),
      cos(time * 0.8 + aRandom * 20.0),
      sin(time * 1.2 + aRandom * 5.0)
    );
    
    finalPos += offset * (driftIntensity + swayIntensity);

    vec4 mvPosition = modelViewMatrix * vec4(finalPos, 1.0);
    gl_Position = projectionMatrix * mvPosition;
    
    // Size attenuation
    gl_PointSize = aSize * (150.0 / -mvPosition.z);
    
    // Fade out slightly when scattering
    vAlpha = 0.8 + 0.2 * t;
  }
`;

const fragmentShader = `
  varying vec3 vColor;
  varying float vAlpha;

  void main() {
    // Circular particle
    vec2 xy = gl_PointCoord.xy - vec2(0.5);
    float r = length(xy);
    if (r > 0.5) discard;

    // Soft glow edge
    float glow = 1.0 - (r * 2.0);
    glow = pow(glow, 1.5);

    gl_FragColor = vec4(vColor, vAlpha * glow);
    
    #include <tonemapping_fragment>
    #include <colorspace_fragment>
  }
`;

export const Foliage: React.FC<FoliageProps> = ({ isAssembled }) => {
  const shaderRef = useRef<THREE.ShaderMaterial>(null);
  const progressRef = useRef(isAssembled ? 1 : 0);

  const { positions, treePositions, colors, sizes, randoms } = useMemo(() => {
    const count = 4500; // High Density
    const pos = new Float32Array(count * 3);
    const treePos = new Float32Array(count * 3);
    const col = new Float32Array(count * 3);
    const sz = new Float32Array(count);
    const rnd = new Float32Array(count);

    const colorGreenDeep = new THREE.Color(COLORS.EMERALD_DEEP); // #013220
    const colorGreenDark = new THREE.Color("#002211"); 
    const colorGoldDust = new THREE.Color(COLORS.GOLD_METALLIC);

    for (let i = 0; i < count; i++) {
      // 1. SCATTER POSITION
      const r = 12 * Math.cbrt(Math.random());
      const theta = Math.random() * Math.PI * 2;
      const phi = Math.acos(2 * Math.random() - 1);
      
      pos[i * 3] = r * Math.sin(phi) * Math.cos(theta);
      pos[i * 3 + 1] = r * Math.sin(phi) * Math.sin(theta);
      pos[i * 3 + 2] = r * Math.cos(phi);

      // 2. TREE POSITION (Cone)
      // Height ~7, Base Radius ~2.8
      const h = Math.random() * 7; 
      const coneRadiusAtH = 2.8 * (1 - h / 7);
      const angle = Math.random() * Math.PI * 2;
      // Bias slightly towards surface for density
      const radBias = Math.random(); 
      const rad = coneRadiusAtH * (0.2 + 0.8 * Math.sqrt(radBias)); 
      
      treePos[i * 3] = Math.cos(angle) * rad;
      treePos[i * 3 + 1] = h - 3.5; 
      treePos[i * 3 + 2] = Math.sin(angle) * rad;

      // 3. COLOR (Deep Green with occasional Gold Dust)
      const isGoldDust = Math.random() > 0.98;
      const c = isGoldDust ? colorGoldDust : (Math.random() > 0.5 ? colorGreenDeep : colorGreenDark);
      
      col[i * 3] = c.r;
      col[i * 3 + 1] = c.g;
      col[i * 3 + 2] = c.b;

      sz[i] = Math.random() * 0.5 + 0.3; // Slightly bigger particles for fluffiness
      rnd[i] = Math.random();
    }

    return {
      positions: pos,
      treePositions: treePos,
      colors: col,
      sizes: sz,
      randoms: rnd
    };
  }, []);

  useFrame((state, delta) => {
    if (shaderRef.current) {
      shaderRef.current.uniforms.uTime.value = state.clock.elapsedTime;
      const target = isAssembled ? 1 : 0;
      progressRef.current = THREE.MathUtils.damp(progressRef.current, target, 2.5, delta);
      shaderRef.current.uniforms.uProgress.value = progressRef.current;
    }
  });

  return (
    <points>
      <bufferGeometry>
        <bufferAttribute
          attach="attributes-position"
          count={positions.length / 3}
          array={positions}
          itemSize={3}
        />
        <bufferAttribute
          attach="attributes-aTreePos"
          count={treePositions.length / 3}
          array={treePositions}
          itemSize={3}
        />
        <bufferAttribute
          attach="attributes-color"
          count={colors.length / 3}
          array={colors}
          itemSize={3}
        />
        <bufferAttribute
          attach="attributes-aSize"
          count={sizes.length}
          array={sizes}
          itemSize={1}
        />
        <bufferAttribute
          attach="attributes-aRandom"
          count={randoms.length}
          array={randoms}
          itemSize={1}
        />
      </bufferGeometry>
      <shaderMaterial
        ref={shaderRef}
        vertexShader={vertexShader}
        fragmentShader={fragmentShader}
        uniforms={{
          uTime: { value: 0 },
          uProgress: { value: 0 },
        }}
        transparent
        depthWrite={false}
        blending={THREE.NormalBlending}
        vertexColors
      />
    </points>
  );
};