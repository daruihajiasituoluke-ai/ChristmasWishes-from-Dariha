import React, { useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import * as THREE from 'three';
import { COLORS } from '../constants';
import { OrnamentsContainer } from './Ornaments';
import { Foliage } from './Foliage';

interface TreeProps {
  isAssembled: boolean;
}

export const ChristmasTree: React.FC<TreeProps> = ({ isAssembled }) => {
  const trunkRef = useRef<THREE.Group>(null);

  // Animation Loop for Trunk
  useFrame((state, delta) => {
    const target = isAssembled ? 1 : 0;
    
    if (trunkRef.current) {
         trunkRef.current.userData.lerp = THREE.MathUtils.damp(
            trunkRef.current.userData.lerp || 0, 
            target, 
            1.5, 
            delta
        );
        const val = trunkRef.current.userData.lerp;

        trunkRef.current.scale.setScalar(val);
        trunkRef.current.position.y = THREE.MathUtils.lerp(-8, 0, val);
        trunkRef.current.rotation.y += delta * 0.05;
    }
  });

  return (
    <group>
      {/* 1. Deep Green Dense Foliage */}
      <Foliage isAssembled={isAssembled} />

      {/* 2. Luxury Ornaments, Ribbons, and Gold Spray Topper */}
      <OrnamentsContainer isAssembled={isAssembled} />

      {/* 3. The Trunk & Pot */}
      <group ref={trunkRef}>
        <mesh position={[0, -2.5, 0]} castShadow receiveShadow>
          <cylinderGeometry args={[0.4, 0.6, 1.5, 16]} />
          {/* Dark Wood Trunk */}
          <meshStandardMaterial color="#221100" roughness={1} />
        </mesh>
        
        {/* Luxury Gold/Blue Pot */}
        <mesh position={[0, -3.2, 0]} receiveShadow>
          <cylinderGeometry args={[0.7, 0.5, 0.7, 32]} />
          <meshStandardMaterial 
              color={COLORS.EMERALD_MAIN} 
              metalness={0.8} 
              roughness={0.2} 
          />
        </mesh>
        <mesh position={[0, -2.85, 0]} receiveShadow>
             <torusGeometry args={[0.7, 0.05, 16, 64]} />
             <meshStandardMaterial color={COLORS.GOLD_METALLIC} metalness={1} roughness={0.1} />
        </mesh>
      </group>
    </group>
  );
};