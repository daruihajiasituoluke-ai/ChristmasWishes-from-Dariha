import React, { useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import { COLORS } from '../constants';
import * as THREE from 'three';

export const Lights: React.FC = () => {
  const groupRef = useRef<THREE.Group>(null);
  const keyLightRef = useRef<THREE.SpotLight>(null);
  const rimLightRef = useRef<THREE.SpotLight>(null);

  useFrame((state) => {
    const time = state.clock.elapsedTime;

    if (groupRef.current) {
      groupRef.current.rotation.y = time * 0.05;
    }

    // Dynamic flickering for the main Gold light
    if (keyLightRef.current) {
      // Base intensity 2800, slow warm breathing
      keyLightRef.current.intensity = 2800 + Math.sin(time * 1.5) * 300 + (Math.random() - 0.5) * 100;
    }
  });

  return (
    <group ref={groupRef}>
      {/* Key Light - Warm Tungsten Gold - Main source */}
      <spotLight
        ref={keyLightRef}
        position={[10, 15, 10]}
        angle={0.4}
        penumbra={0.5}
        intensity={2800}
        color="#FFD700"
        castShadow
        shadow-bias={-0.0001}
        shadow-mapSize={[2048, 2048]}
      />

      {/* Fill Light - Cool Royal Blue to bring out the ribbons */}
      <pointLight
        position={[-10, 5, -10]}
        intensity={800}
        color="#4169E1"
        distance={30}
        decay={2}
      />

      {/* Rim Light - Sharp White/Gold for edge definition */}
      <spotLight
        ref={rimLightRef}
        position={[0, 10, -10]}
        angle={0.6}
        penumbra={0.5}
        intensity={2000}
        color="#FFFACD"
      />
      
      {/* Ambient floor glow - Deep Gold */}
      <ambientLight intensity={0.5} color="#332200" />
    </group>
  );
};