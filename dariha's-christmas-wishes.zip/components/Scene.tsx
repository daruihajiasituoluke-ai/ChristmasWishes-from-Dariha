import React, { Suspense } from 'react';
import { Canvas } from '@react-three/fiber';
import { Environment, OrbitControls, ContactShadows, Sparkles } from '@react-three/drei';
import { EffectComposer, Bloom, Vignette, Noise } from '@react-three/postprocessing';
import { ChristmasTree } from './Tree';
import { Lights } from './Lights';
import { COLORS } from '../constants';

interface SceneProps {
  isAssembled: boolean;
}

export const Scene: React.FC<SceneProps> = ({ isAssembled }) => {
  return (
    <Canvas
      shadows
      camera={{ position: [0, 0, 12], fov: 40 }} // Pulled back and centered
      dpr={[1, 2]} // Optimize for varying pixel ratios
      gl={{ antialias: false, toneMapping: 3, toneMappingExposure: 1.2 }} // Tone mapping for cinematic look
    >
      <color attach="background" args={[COLORS.BACKGROUND]} />
      
      {/* Environment for Reflections */}
      <Environment preset="city" blur={1} background={false} />

      <Suspense fallback={null}>
        {/* Lifted the tree up (y=0.8) so it sits comfortably above the bottom UI */}
        <group position={[0, 0.8, 0]}>
            <ChristmasTree isAssembled={isAssembled} />
            
            {/* Floor Reflections/Shadows */}
            <ContactShadows 
                resolution={1024} 
                scale={20} 
                blur={2} 
                opacity={0.5} 
                far={10} 
                color={COLORS.GOLD_RICH} 
            />
            
            {/* Floating ambient particles for magic feel */}
            <Sparkles 
                count={100} 
                scale={10} 
                size={2} 
                speed={0.2} 
                opacity={0.5} 
                color={COLORS.GOLD_CHAMPAGNE} 
            />
        </group>
        
        <Lights />
      </Suspense>

      {/* Camera Controls */}
      <OrbitControls 
        enablePan={false} 
        minPolarAngle={Math.PI / 4} 
        maxPolarAngle={Math.PI / 1.8}
        minDistance={8}
        maxDistance={15}
        autoRotate
        autoRotateSpeed={isAssembled ? 0.5 : 0.1} // Slow down when scattered
        target={[0, 0.5, 0]} // Look slightly up at the tree center
      />

      {/* Post Processing for the "Cinematic Glow" */}
      <EffectComposer enableNormalPass={false}>
        {/* Bloom creates the glowing gold effect */}
        <Bloom 
            luminanceThreshold={1} 
            mipmapBlur 
            intensity={1.5} 
            radius={0.7} 
        />
        <Vignette eskil={false} offset={0.1} darkness={1.1} />
        <Noise opacity={0.02} />
      </EffectComposer>
    </Canvas>
  );
};