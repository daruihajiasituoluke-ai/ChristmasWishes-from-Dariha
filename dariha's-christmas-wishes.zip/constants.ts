export const COLORS = {
  EMERALD_DEEP: "#013220", // Deep Pine Green (Foliage)
  EMERALD_MAIN: "#0F52BA", // Royal Blue
  EMERALD_LIGHT: "#F5F5F5", // Pearl White
  GOLD_METALLIC: "#FFD700", // Bright Metallic Gold
  GOLD_CHAMPAGNE: "#F5BD02", // Warm Gold
  GOLD_RICH: "#D4AF37", // Deep Gold
  BACKGROUND: "#02040a", // Deep Dark Blue/Black
};

export const FESTIVE_COLORS = [
  "#FFD700", // Gold
  "#0F52BA", // Royal Blue
  "#F5F5F5", // Pearl White
];

export const GEMINI_MODEL = "gemini-2.5-flash";

export const PROMPT_TEMPLATE = `
You are a luxury concierge for 'Arix Signature'. 
Write a short, elegant, and sophisticated Christmas wish (max 20 words). 
The tone should be warm, exclusive, and poetic.
Avoid emojis. 
Return only the text string.
`;